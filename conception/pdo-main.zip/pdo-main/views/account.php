<h1>Profil de <?= $userAccount->username ?></h1>
<p>E-mail : <?= $userAccount->email ?></p>
<p>Date de naissance : <?= $userAccount->birthdateFr ?></p>
<p>Rôle : <?= $userAccount->roleName ?></p>
<a href="/modifier-mon-compte">Modifier mes informations</a>