</main>
<footer>
<p class="footerTitle">La Manu Post</p>
    <p class="footerSubTitle">Démo inscription - connexion - PDO</p>

    <p>
        Dans ce projet, nous allons faire la démonstration pas à pas d'un projet MVC avec du PDO.
    </p>
</footer>
<script src="https://kit.fontawesome.com/b5ca2c911d.js" crossorigin="anonymous"></script>
<script src="assets/js/script.js"></script>
</body>
</html>